attack = ['https://cdn.discordapp.com/attachments/921455758330200135/921455815787958302/FdXPLmh.gif']

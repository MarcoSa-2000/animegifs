# __init__.py
from .get_gif import get_gif
from .gifs import attack

# anime-gifs.py
Get random anime gifs by category. Python.
WIP
